#!/bin/bash
python3 sort.py
read -p "Tryk på enter for at afslutte..."
